This should be run by some command; it may be like a test framework, or just a series of requests and feel free to ask us on what we had in mind with this if it doesn't make sense! Feel free to implement this script in any language.
(We usually use Mocha on Node.js in case you want a hint, Ruby has a couple of options, including RSpec)

- feed the `follows.json` through your `/follow` endpoint, in sequence (or parallel)
- the same for `/listen`
- make a call to user "a" on `/recommendations` and display the results

